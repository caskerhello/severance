-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: severance
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor` (
  `dseq` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `doctorsection` int DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `savefilename` varchar(255) DEFAULT NULL,
  `daylimit` varchar(7) DEFAULT NULL,
  `bachd` varchar(100) DEFAULT NULL,
  `mastd` varchar(100) DEFAULT NULL,
  `doctd` varchar(100) DEFAULT NULL,
  `resume` varchar(255) DEFAULT NULL,
  `univlogo` varchar(255) DEFAULT NULL,
  `univlogofilename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dseq`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (1,'박지성',1,'정형외과는 근골격계의 질환과 손상을 치료하고 예방하는 의학 분야입니다. 근골격계에는 뼈, 관절, 인대, 힘줄, 근육 등이 포함됩니다. 이 분야의 의료진은 골절, 관절염, 척추 문제, 스포츠 부상, 선천적 기형 등의 치료를 전문으로 합니다. 주요 치료 방법으로는 수술(관절 치환술, 척추 수술 등), 물리치료, 재활치료가 포함됩니다.','1_profile.jpg','1_profile.jpg','1000001','가톨릭대학교 의과대학 학사 (2008)','가톨릭대학교 의학과 석사 (2011)','가톨릭대학교 의학과 박사 (2016)','2022~현재: 신촌 세브란스병원 정형외과 조교수','catholic.png','catholic.png'),(2,'최민아',2,'이비인후과는 귀(Ear), 코(Nose), 목(Throat)의 질환을 진단하고 치료하는 분야입니다. 이 분야에서는 난청, 이명, 코 막힘, 축농증, 편도선염, 성대 질환, 후두암 등의 다양한 상태를 다룹니다. 또한 균형 장애, 수면 무호흡증, 알레르기 치료 등도 포함됩니다. 이비인후과 의사는 미세수술 및 내시경을 활용한 고난도의 수술을 전문으로 합니다. ','4_profile.jpg','4_profile.jpg','1000001','서울대학교 의과대학 학사 (2011)','서울대학교 의학과 석사 (2014)','서울대학교 의학과 박사 (2019)','2023~현재: 신촌 세브란스병원 조교수','seoul.png','seoul.png'),(3,'이서준',3,'외과는 다양한 신체 부위의 외과적 치료를 다루는 의학 분야로, 내과적 치료로 해결되지 않는 질환을 수술적으로 치료합니다. 주요 영역에는 일반 외과(복부 수술, 장기 제거), 암 수술, 혈관 수술, 소화기 수술 등이 포함됩니다. 외과 의사는 세부적으로 간, 담도, 췌장, 위장관 등 특정 기관을 전문으로 다루는 경우가 많습니다. ','7_profile.jpg','7_profile.jpg','1000001','연세대학교 의과대학 학사 (2010)','연세대학교 의학과 석사 (2013)','연세대학교 의학과 박사 (2017)','2023~현재: 신촌 세브란스병원 외과 조교수','yonsei.png','yonsei.png'),(4,'장태영',4,'산부인과는 여성의 생식기 건강과 출산, 임신을 다루는 분야입니다. 산과(Obstetrics)는 임신, 출산, 산후 관리를 전문으로 하며, 부인과(Gynecology)는 자궁, 난소, 질 등 여성 생식기의 질환(자궁근종, 난소암, 자궁내막증)을 진단하고 치료합니다. 이 외에도 불임 치료, 호르몬 관리, 생리 관련 문제를 다룹니다. ','10_profile.jpg','10_profile.jpg','1000001','경희대학교 의과대학 학사 (2009)','경희대학교 의학과 석사 (2012)','경희대학교 의학과 박사 (2017)','2023~현재: 신촌 세브란스병원 산부인과 교수','kyunghee.png','kyunghee.png'),(5,'정민재',5,'비뇨기과는 남성과 여성의 비뇨기계(신장, 요관, 방광, 요도) 및 남성 생식기의 질환을 다루는 의학 분야입니다. 주요 질환에는 전립선 비대증, 방광염, 신장 결석, 요로감염, 불임, 성기능 장애 등이 있습니다. 비뇨기과 의사는 복강경 수술, 로봇 수술 등 최신 기술을 활용하여 수술을 진행하며, 남성 건강 및 성 기능 관련 치료도 전문적으로 수행합니다. ','11_profile.jpg','11_profile.jpg','1000001','고려대학교 의과대학 학사 (2007)','고려대학교 의학과 석사 (2010)','고려대학교 의학과 박사 (2015)','2022~현재: 신촌 세브란스병원 임상조교수','consideration.png','consideration.png'),(6,'김다은',1,'정형외과는 근골격계의 질환과 손상을 치료하고 예방하는 의학 분야입니다. 근골격계에는 뼈, 관절, 인대, 힘줄, 근육 등이 포함됩니다. 이 분야의 의료진은 골절, 관절염, 척추 문제, 스포츠 부상, 선천적 기형 등의 치료를 전문으로 합니다. 주요 치료 방법으로는 수술(관절 치환술, 척추 수술 등), 물리치료, 재활치료가 포함됩니다.','2_profile.jpg','2_profile.jpg','1000001','연세대학교 의과대학 학사 (2008)','연세대학교 의학과 석사 (2011)','연세대학교 의학과 박사 (2015)','2019~현재: 신촌 세브란스병원 교수','yonsei.png','yonsei.png'),(7,'김현우',2,'이비인후과는 귀(Ear), 코(Nose), 목(Throat)의 질환을 진단하고 치료하는 분야입니다. 이 분야에서는 난청, 이명, 코 막힘, 축농증, 편도선염, 성대 질환, 후두암 등의 다양한 상태를 다룹니다. 또한 균형 장애, 수면 무호흡증, 알레르기 치료 등도 포함됩니다. 이비인후과 의사는 미세수술 및 내시경을 활용한 고난도의 수술을 전문으로 합니다. ','5_profile.jpg','5_profile.jpg','1000001','서울대학교 의과대학 학사 (2005)','서울대학교 의학과 석사 (2008)','서울대학교 의학과 박사 (2012)','2022~현재: 신촌 세브란스병원 교수','seoul.png','seoul.png'),(8,'강유진',3,'외과는 다양한 신체 부위의 외과적 치료를 다루는 의학 분야로, 내과적 치료로 해결되지 않는 질환을 수술적으로 치료합니다. 주요 영역에는 일반 외과(복부 수술, 장기 제거), 암 수술, 혈관 수술, 소화기 수술 등이 포함됩니다. 외과 의사는 세부적으로 간, 담도, 췌장, 위장관 등 특정 기관을 전문으로 다루는 경우가 많습니다. ','14_profile.jpg','14_profile.jpg','1000001','서울대학교 의과대학 학사 (2006)','서울대학교 의학과 석사 (2009)','서울대학교 의학과 박사 (2013)','2017~현재: 신촌 세브란스병원 교수','seoul.png','seoul.png'),(9,'홍지훈',4,'산부인과는 여성의 생식기 건강과 출산, 임신을 다루는 분야입니다. 산과(Obstetrics)는 임신, 출산, 산후 관리를 전문으로 하며, 부인과(Gynecology)는 자궁, 난소, 질 등 여성 생식기의 질환(자궁근종, 난소암, 자궁내막증)을 진단하고 치료합니다. 이 외에도 불임 치료, 호르몬 관리, 생리 관련 문제를 다룹니다. ','12_profile.jpg','12_profile.jpg','1000001','전남대학교 의과대학 학사 (2007)','전남대학교 의학과 석사 (2010)','전남대학교 의학과 박사 (2015)','2019~현재: 신촌 세브란스병원 교수','jeonnam.png','jeonnam.png'),(10,'최은석',5,'비뇨기과는 남성과 여성의 비뇨기계(신장, 요관, 방광, 요도) 및 남성 생식기의 질환을 다루는 의학 분야입니다. 주요 질환에는 전립선 비대증, 방광염, 신장 결석, 요로감염, 불임, 성기능 장애 등이 있습니다. 비뇨기과 의사는 복강경 수술, 로봇 수술 등 최신 기술을 활용하여 수술을 진행하며, 남성 건강 및 성 기능 관련 치료도 전문적으로 수행합니다. ','8_profile.jpg','8_profile.jpg','1000001','부산대학교 의과대학 학사 (2011)','부산대학교 의학과 석사 (2014)','부산대학교 의학과 박사 (2019)','2023~현재: 신촌 세브란스병원 조교수','busan.png','busan.png'),(11,'임수현',1,'정형외과는 근골격계의 질환과 손상을 치료하고 예방하는 의학 분야입니다. 근골격계에는 뼈, 관절, 인대, 힘줄, 근육 등이 포함됩니다. 이 분야의 의료진은 골절, 관절염, 척추 문제, 스포츠 부상, 선천적 기형 등의 치료를 전문으로 합니다. 주요 치료 방법으로는 수술(관절 치환술, 척추 수술 등), 물리치료, 재활치료가 포함됩니다. ','9_profile.jpg','9_profile.jpg','1000001','인하대학교 의과대학 학사 (2009)','인하대학교 의학과 석사 (2012)','인하대학교 의학과 박사 (2017)','2019~현재: 신촌 세브란스병원 교수','inha.png','inha.png'),(12,'조민지',2,'이비인후과는 귀(Ear), 코(Nose), 목(Throat)의 질환을 진단하고 치료하는 분야입니다. 이 분야에서는 난청, 이명, 코 막힘, 축농증, 편도선염, 성대 질환, 후두암 등의 다양한 상태를 다룹니다. 또한 균형 장애, 수면 무호흡증, 알레르기 치료 등도 포함됩니다. 이비인후과 의사는 미세수술 및 내시경을 활용한 고난도의 수술을 전문으로 합니다. ','15_profile.jpg','15_profile.jpg','1000001','울산대학교 의과대학 학사 (2012)','울산대학교 의학과 석사 (2015)','울산대학교 의학과 박사 (2020)','2023~현재: 신촌 세브란스병원 조교수','ulsan.png','ulsan.png'),(13,'장유진',3,'외과는 다양한 신체 부위의 외과적 치료를 다루는 의학 분야로, 내과적 치료로 해결되지 않는 질환을 수술적으로 치료합니다. 주요 영역에는 일반 외과(복부 수술, 장기 제거), 암 수술, 혈관 수술, 소화기 수술 등이 포함됩니다. 외과 의사는 세부적으로 간, 담도, 췌장, 위장관 등 특정 기관을 전문으로 다루는 경우가 많습니다. ','6_profile.jpg','6_profile.jpg','1000001','경희대학교 의과대학 학사 (2010)','경희대학교 의학과 석사 (2013)','경희대학교 의학과 박사 (2018)','2022~현재: 신촌 세브란스병원 교수','kyunghee.png','kyunghee.png'),(14,'이준혁',3,'외과는 다양한 신체 부위의 외과적 치료를 다루는 의학 분야로, 내과적 치료로 해결되지 않는 질환을 수술적으로 치료합니다. 주요 영역에는 일반 외과(복부 수술, 장기 제거), 암 수술, 혈관 수술, 소화기 수술 등이 포함됩니다. 외과 의사는 세부적으로 간, 담도, 췌장, 위장관 등 특정 기관을 전문으로 다루는 경우가 많습니다. ','3_profile.jpg','3_profile.jpg','1000001','고려대학교 의과대학 학사 (2010)','고려대학교 의학과 석사 (2013)','고려대학교 의학과 박사 (2018)','2022~현재: 신촌 세브란스병원 교수','consideration.png','consideration.png'),(15,'박수현',4,'산부인과는 여성의 생식기 건강과 출산, 임신을 다루는 분야입니다. 산과(Obstetrics)는 임신, 출산, 산후 관리를 전문으로 하며, 부인과(Gynecology)는 자궁, 난소, 질 등 여성 생식기의 질환(자궁근종, 난소암, 자궁내막증)을 진단하고 치료합니다. 이 외에도 불임 치료, 호르몬 관리, 생리 관련 문제를 다룹니다. ','13_profile.jpg','13_profile.jpg','1000001','부산대학교 의과대학 학사 (2009)','부산대학교 의학과 석사 (2012)','부산대학교 의학과 박사 (2017)','2022~현재: 신촌 세브란스병원 교수','busan.png','busan.png');
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-18 13:30:32
